from .excel_haplotype import main1

def main():
    main1()

if __name__ == '__main__':
    main()